#include <stdbool.h>
#define EXIT_FAILURE 1
#define MAXRECORD 40          /* Define the number of the record */
#define MAXBANDACCOUNT 3      /* Define the number of the bandaccount */
#define NUM_USERS 254           /* The maximum number of users */


extern int currentuserNum; /* Declare the variable from account.h as global variable. */
extern int currentTransNum; /* Declare the variable from account.h as global variable. */


typedef enum {
    SAVING,         /* integer==1 */
    WITHDRAWN       /* integer!=1(2) */
} TransactionType;

typedef enum {
    CHEQUING,
    SAVINGS,
    READLINE
} AccountType;

typedef struct Transaction {
    TransactionType transactiontype;
    float amount;
    char *timebuffer;
} bankaccount_transaction;

typedef struct BankAccount {
    int baseaccount;
    int subaccountid;
    AccountType accounttype;
    float balance;
    float total;
    time_t timestamp;
    char *creationTimeStr;
    bankaccount_transaction *pTransaction[MAXRECORD];
    int transactionCount;
} bankaccount_account;

typedef struct User {
    int userid;
    char *username[30];
    bankaccount_account *pBankAccount[MAXBANDACCOUNT];
} bankuser_user;

extern bankuser_user *users[NUM_USERS];

/*
 * Generates a random floating-point number.
 * @param positive Flag indicating if the number should be positive.
 * @param negtive Flag indicating if the number should be negative.
 * @return A random float.
 */
float getRandom(int positive, int negtive);

/*
 * Reads a name input from the user.
 * @return A dynamically allocated string containing the input name.
 */
char *input_name();

/*
 * Converts a username to a user ID.
 * @param username The username string.
 * @return The corresponding user ID, or an error code if not found.
 */
int usernametoID(char *username);

/*
 * Gets the current time as a formatted string.
 * @return A dynamically allocated string containing the current time.
 */
char *gettime();

/*
 * Clears the input buffer to prevent issues with subsequent input.
 */
void clearInputBuffer();

/*
 * Prints the main bank account menu to the console.
 */
void printbankaccountMenu();

/*
 * Sets the account type for a given bank account.
 * @param pbankaccount Pointer to the bank account structure.
 * @param accountType The account type to set.
 */
void setAccountType(bankaccount_account *pbankaccount, int accountType);

/*
 * Sets the transaction type for a given transaction.
 * @param ptransaction Pointer to the transaction structure.
 * @param amount The amount of the transaction.
 */
void setTransactionType(bankaccount_transaction *ptransaction, float amount);

/*
 * Gets the string representation of a TransactionType.
 * @param type The TransactionType enum value.
 * @return A constant character pointer to the string representation.
 */
const char *getTransactionTypeString(TransactionType type);

/*
 * Gets the string representation of an AccountType.
 * @param type The AccountType enum value.
 * @return A constant character pointer to the string representation.
 */
const char *getBankaccountTypeString(AccountType type);

/*
 * Handles user deposit or withdrawal operations.
 * @param depositwithdraw An integer indicating the type of operation (e.g., 1 for deposit, 2 for withdrawal).
 * @param userArray An array of bank user structures.
 * @param userCount The number of users in the array.
 */
void userDepositWithdraw(int depositwithdraw, bankuser_user *userArray[], int userCount);

/*
 * Performs a deposit or withdrawal operation for a specific user and account.
 * @param dwtype An integer indicating the type of operation (e.g., 1 for deposit, 2 for withdrawal).
 * @param existuser Pointer to the existing bank user structure.
 * @param account_id The ID of the account to perform the operation on.
 * @param amount The amount to deposit or withdraw.
 * @return A boolean value indicating the success or failure of the operation.
 */
bool usersubDW(int dwtype,bankuser_user *existuser,int account_id,float amount);

/*
 * Displays the details of a specific user.
 */
void userDisplay();

/*
 * Lists all users in the system.
 */
void userList();

/*
 * Lists all accounts for a specific user.
 */
void useraccountList();

/*
 * Prepares a new user structure with initial account information.
 * @param newUser Pointer to the new bank user structure.
 * @param choice_account The type of initial account to create.
 */
void userpreprint(bankuser_user *newUser,int choice_account);

/*
 * Creates a new transaction record.
 * @param amount The amount of the transaction.
 * @return A pointer to the newly created bankaccount_transaction structure.
 */
bankaccount_transaction *createTransaction(float amount);

/*
 * Creates a new bank account record.
 * @param accountType The type of the account to create.
 * @param amount The initial amount for the account.
 * @return A pointer to the newly created bankaccount_account structure.
 */
bankaccount_account *createBankaccount(int accountType, float amount);

/*
 * Creates a new bank user record.
 * @return A pointer to the newly created bankuser_user structure.
 */
bankuser_user *createBankuser();

/*
 * Creates a new bank account based on user's choice.
 * @param choice An integer representing the user's account type choice.
 * @param amount The initial amount for the account.
 * @param name The name associated with the account (potentially user's name).
 * @return A pointer to the newly created bankaccount_account structure.
 */
bankaccount_account* createAccountBasedOnChoice(int choice, float amount, char *name);

/*
 * Finds a bank user by their username.
 * @param name The username to search for.
 * @param userArray An array of bank user structures.
 * @param userCount The number of users in the array.
 * @return A pointer to the found bankuser_user structure, or NULL if not found.
 */
bankuser_user *pbankuser(char *name, bankuser_user *userArray[], int userCount);