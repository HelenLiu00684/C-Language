#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "account.h"
#include <stdbool.h>





bankuser_user *users[NUM_USERS];

/*
 * Main function of the Bank Account System.
 * This function displays the main menu and handles user interactions
 * for creating accounts, depositing, withdrawing, displaying account details, and exiting.
 * @param void No arguments.
 * @return 0 if the program executes successfully, otherwise returns an error code (e.g., EXIT_FAILURE).
 */
int main(void) {


    char choice_char;
    /*bankuser_user *users[NUM_USERS];*/
    while(true){
        printf("Bank Account System Menu:\n");
        printf("1. Create Account\n");
        printf("2. Deposit Money\n");
        printf("3. Withdraw Money\n");
        printf("4. Display Account Details\n");
        printf("5. Exit\n");
        printf("Enter your choice (1/2/3/4/5): ");


        scanf(" %c", &choice_char); /* Important: Space before %c to consume leftover newline*/
        clearInputBuffer();



        switch (choice_char) {
            case '1':
                users[currentuserNum] = createBankuser();
                if (users[currentuserNum] == NULL) {
                    printf("Failed to create user %d.\n", currentuserNum + 1);
                    return  EXIT_FAILURE;
                }

                if (users[currentuserNum] != NULL) {
                    printf("\n----- User Information for User %d -----:\n", currentuserNum + 1);
                    printf("User ID: %d\n", users[currentuserNum]->userid);
                    printf("Username: %s\n", users[currentuserNum]->username[0]);
                    printf("Chequing Total: %.2f     Saving Total: %.2f  ReadLine Total: %.2f\n", users[currentuserNum]->pBankAccount[0]->total,users[currentuserNum]->pBankAccount[1]->total,users[currentuserNum]->pBankAccount[2]->total);
                }
                currentuserNum++;
                break;
            case '2':
            /*
             * Handles the deposit operation for an existing user.
             * Calls the userDepositWithdraw function with the deposit operation type (1).
             */
            userDepositWithdraw(1, users, currentuserNum);
                break;
            case '3':
            /*
             * Handles the withdrawal operation for an existing user.
             * Calls the userDepositWithdraw function with the withdrawal operation type (2).
             */
            userDepositWithdraw(2, users, currentuserNum);
                break;
            case '4':
            /*
             * Displays the account details for a selected user.
             * Calls the userDisplay function to handle the display process.
             */
            userDisplay();
                break;
            case '5':
            /*
             * Exits the Bank Account System.
             */
                exit(0);
                break;
            default:
                printf("Invalid choice.\n");
                break;
        }
    }

    return 0; /* Good practice*/
}