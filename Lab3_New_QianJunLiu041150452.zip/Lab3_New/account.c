#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <stdbool.h>
#include "account.h"


int global_checuing = 0;
int global_saving = 0;
int global_readline = 0;
int global_userid = 0;

bankuser_user *puser=NULL;
bankaccount_account *pbankaccount;
bankaccount_transaction *ptransaction;
bankuser_user *newUser;



int currentuserNum = 0;


/*
 * Clears the input buffer to remove any remaining characters, especially newline.
 */
void clearInputBuffer() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF) {
    }
}

/*
 * Reads a name input from the user from standard input.
 * Allocates memory for the input name.
 * @return A pointer to the dynamically allocated string containing the user's name,
 * or NULL if memory allocation fails or an error occurs during reading.
 */
char *input_name() {
    char *input_name = (char *)malloc(50 * sizeof(char));
    if (input_name == NULL) {
        perror("Failed to allocate memory");
        return NULL;
    }
    printf("please input your name:");
    if (fgets(input_name, 50, stdin) != NULL) {
        char *ptr = input_name;
        while (*ptr != '\0') {
            if (*ptr == '\n') {
                *ptr = '\0';
                break;
            }
            ptr++;
        }
        printf("you name is :%s\n", input_name);
        return input_name;
    } else {
        printf("reading error\n");
        free(input_name);
        return NULL;
    }
}

/*
 * Gets the current date and time as a formatted string.
 * Allocates memory for the timestamp string.
 * @return A pointer to the dynamically allocated string containing the current timestamp
 * in the format "YYYY-MM-DD HH:MM:SS", or NULL if memory allocation fails.
 */
char *gettime() {
    char *buffer;
    time_t timer;
    struct tm *tm_info;
    time(&timer);
    buffer = (char *)malloc(40 * sizeof(char));
    if (buffer == NULL) {
        perror("alloc memory failed");
        exit(EXIT_FAILURE);
    }
    tm_info = localtime(&timer);
    strftime(buffer, 40, "%Y-%m-%d %H:%M:%S", tm_info);
    return buffer;
}

/*
 * Creates a new transaction record.
 * Allocates memory for the transaction structure and its timestamp.
 * Sets the transaction type based on the amount (SAVING for positive, WITHDRAWN for non-positive).
 * @param amount The amount of the transaction.
 * @return A pointer to the newly created bankaccount_transaction structure,
 * or NULL if memory allocation fails.
 */
bankaccount_transaction *createTransaction(float amount) {
    ptransaction = (bankaccount_transaction *)malloc(sizeof(bankaccount_transaction));
    if (ptransaction == NULL) {
        perror("Failed to allocate memory for Transaction");
        return NULL;
    }
    ptransaction->amount = amount;
    ptransaction->timebuffer = gettime();
    if (amount > 0) {
        ptransaction->transactiontype = SAVING;
    } else {
        ptransaction->transactiontype = WITHDRAWN;
    }
    return ptransaction;
}

/*
 * Initializes a new bank account structure.
 * Allocates memory for the bank account and initializes its members, including transaction history.
 * Sets the account type, timestamp, creation time, balance, and total.
 * @param accountType The type of the account to create (CHEQUING, SAVINGS, READLINE).
 * @param amount The initial amount for the account.
 * @return A pointer to the newly created bankaccount_account structure,
 * or NULL if memory allocation fails.
 */
bankaccount_account *createBankaccount(int accountType, float amount) { /*Initialize One Bank Account*/
    int i = 0;
    pbankaccount = (bankaccount_account *)malloc(sizeof(bankaccount_account));
    if (pbankaccount == NULL) {
        perror("Failed to allocate memory for Bankaccount");
        return NULL;
    }
    setAccountType(pbankaccount, accountType); /*Initialize One Bank Account*/
    pbankaccount->timestamp = time(NULL);
    pbankaccount->creationTimeStr = gettime();
    pbankaccount->balance = amount;
    pbankaccount->total = amount;
    for (i = 0; i < MAXRECORD; i++) {
        pbankaccount->pTransaction[i] = NULL; /*Initialize to NULL*/
    }
    pbankaccount->transactionCount = 0;
    return pbankaccount;
}

/*
 * Initializes a new bank user structure.
 * Prompts the user for their name, checks for duplicates, and creates initial bank accounts (Chequing, Saving, ReadLine).
 * Allows the user to make an initial deposit into one of the accounts.
 * Assigns a unique user ID.
 * @return A pointer to the newly created bankuser_user structure,
 * or NULL if memory allocation fails or the username is a duplicate.
 */
bankuser_user *createBankuser(){    /*Initialize One Bank User*/
    char *name;
    float amount=0;
    char choice_char;
    int choice_int;
    int index;
    newUser = (bankuser_user *)malloc(sizeof(bankuser_user));

    if (newUser == NULL) {
        perror("Failed to allocate memory for User");
        return NULL;
    }

    name = input_name();

    /*printf("The result of checking user is %d\n",usernametoID(name));*/
    if (name == NULL) {
        perror("The name is duplicated. \n");
        free(newUser);
        return NULL;
    }

    if(usernametoID(name)!=-1){
        printf("The result of checking user is %d\n",usernametoID(name));
        perror("The name is duplicated, free the user \n");
        free(newUser);
        return NULL;
    }
    /*Assign username[0] to the string of user's name*/
    newUser->username[0] = (char *)malloc(strlen(name) + 1);
    if (newUser->username[0] == NULL) {
        perror("Failed to allocate memory for username");
        free(name);
        free(newUser);
        return NULL;
    }
    strcpy(newUser->username[0], name);
    free(name); /*Free the function of input_name which allocate memory */

    newUser->pBankAccount[0] = createBankaccount(CHEQUING, 0.0f); /*Create chequing account*/
    if (newUser->pBankAccount[0] == NULL) {
        perror("Failed to create CHEQUING account");
        free(newUser);
        return NULL;
    }

    newUser->pBankAccount[1] = createBankaccount(SAVINGS, 0.0f); /*Create saving account*/
    if (newUser->pBankAccount[1] == NULL) {
        perror("Failed to create SAVINGS account");
        free(newUser->pBankAccount[0]);
        free(newUser);
        return NULL;
    }

    newUser->pBankAccount[2] = createBankaccount(READLINE, 0.0f);    /*Create readline account*/
    if (newUser->pBankAccount[2] == NULL) {
        perror("Failed to create READLINE account");
        free(newUser->pBankAccount[0]);
        free(newUser->pBankAccount[1]);
        free(newUser);
        return NULL;
    }

    printf("Enter initial deposit amount : ");
    scanf(" %e", &amount); /* Important: Space before %c to consume leftover newline*/
    clearInputBuffer();
    printbankaccountMenu();
    printf("Enter your choice (1/2/3): ");
    scanf(" %c", &choice_char); /* Important: Space before %c to consume leftover newline*/
    clearInputBuffer();

    choice_int = choice_char - '0'; /* char convert to int */

    if (choice_int >= 1 && choice_int <= 3) {
        index = choice_int - 1;
        if (newUser->pBankAccount[index] != NULL && newUser->pBankAccount[index]->transactionCount < MAXRECORD) {
            newUser->pBankAccount[index]->total = amount;
            newUser->pBankAccount[index]->balance = amount;
            newUser->pBankAccount[index]->pTransaction[newUser->pBankAccount[index]->transactionCount++] = createTransaction(amount);
        } else {
            printf("Error: Account not properly initialized or transaction history full.\n");
        }
    } else {
        printf("invaild account type choice.Defaulting to Chequing.\n");
        if (newUser->pBankAccount[0] != NULL && newUser->pBankAccount[0]->transactionCount < MAXRECORD) {
            newUser->pBankAccount[0]->total = amount;
            newUser->pBankAccount[0]->balance = amount;
            newUser->pBankAccount[0]->pTransaction[newUser->pBankAccount[0]->transactionCount++] = createTransaction(amount);
        } else {
            printf("Error: Chequing account not properly initialized or transaction history full.\n");
        }
    }
    newUser->userid = 5000+global_userid++; /*The User Id befint from 5XXX*/



    return newUser;
}

/*
 * Creates a new bank account based on the user's choice of account type.
 * Prints a confirmation message indicating the account type and initial balance.
 * @param choice An integer representing the user's account type choice (1 for Chequing, 2 for Saving, 3 for ReadLine).
 * @param amount The initial amount for the account.
 * @param name The name associated with the account (user's name).
 * @return A pointer to the newly created bankaccount_account structure,
 * or NULL if the choice is invalid.
 */
bankaccount_account* createAccountBasedOnChoice(int choice, float amount, char *name) {
    switch (choice) {
        case 1:
            printf("Account CHEQUING created successfully for %s with an inital balance of $%.2f\n", name, amount);
            return createBankaccount(CHEQUING, amount);
        case 2:
            printf("Account SAVING created successfully for %s with an inital balance of $%.2f\n", name, amount);
            return createBankaccount(SAVINGS, amount);
        case 3:
            printf("Account READLINE created successfully for %s with an inital balance of $%.2f\n", name, amount);
            return createBankaccount(READLINE, amount);
        default:
            printf("Wrong choice:%d\n", choice);
            return NULL;
    }
}

/*
 * Sets the transaction type of a transaction record based on the amount.
 * If the amount is positive, the type is set to SAVING; otherwise, it's set to WITHDRAWN.
 * @param ptransaction Pointer to the transaction structure.
 * @param amount The amount of the transaction.
 */
void setTransactionType(bankaccount_transaction *ptransaction, float amount) {
    ptransaction->amount = amount;
    ptransaction->transactiontype = (amount > 0) ? SAVING : WITHDRAWN;
}

/*
 * Sets the account type and assigns a unique sub-account ID based on the chosen type.
 * Uses global counters to generate unique sub-account IDs for each account type.
 * @param pbankaccount Pointer to the bank account structure.
 * @param accountType An integer representing the account type (0 for CHEQUING, 1 for SAVINGS, 2 for READLINE).
 */
void setAccountType(bankaccount_account *pbankaccount, int accountType) {    /* Depend on the accountType to give a different accountID   */
    pbankaccount->accounttype = accountType;
    if (accountType == 0) {
        pbankaccount->accounttype = CHEQUING;
        pbankaccount->baseaccount = 1000;
        pbankaccount->subaccountid = global_checuing++;
    } else if (accountType == 1) {
        pbankaccount->accounttype = SAVINGS;
        pbankaccount->baseaccount = 2000;
        pbankaccount->subaccountid = global_saving++;
    } else if (accountType == 2) {
        pbankaccount->accounttype = READLINE;
        pbankaccount->baseaccount = 3000;
        pbankaccount->subaccountid = global_readline++;
    }
}

/*
 * Gets the string representation of a TransactionType enum value.
 * @param type The TransactionType enum value.
 * @return A constant character pointer to the string representation ("saving", "withdrawn", or "unknown").
 */
const char *getTransactionTypeString(TransactionType type) {
    switch (type) {
        case SAVING:
            return "saving";
        case WITHDRAWN:
            return "withdrawn";
        default:
            return "unknown";
    }
}

/*
 * Gets the string representation of an AccountType enum value.
 * @param type The AccountType enum value.
 * @return A constant character pointer to the string representation ("chequing", "saving", "readline", or NULL for unknown).
 */
const char *getBankaccountTypeString(AccountType type) {
    switch (type) {
        case CHEQUING:
            return "chequing";
        case SAVINGS:
            return "saving";
        case READLINE:
            return "readline";
        default:
            return NULL;
    }
}

/*
 * Generates a random floating-point number within a specified range.
 * @param positive The upper bound for the positive range.
 * @param negtive The lower bound for the negative range (will be made positive for calculation).
 * @return A random float between -negtive and positive.
 */
float getRandom(int positive, int negtive) {
    double random_float;
    random_float = (double)rand() / RAND_MAX * positive - negtive;
    return random_float;
}

/*
 * Prints the menu options for selecting a bank account type.
 */
void printbankaccountMenu(){
    printf("S Menu:\n");
    printf("1. Chequing\n");
    printf("2. Savings\n");
    printf("3. Readline\n");
}

/*
 * Handles the process of depositing or withdrawing funds for a user.
 * Prompts the user for their name, account choice, and the amount to deposit or withdraw.
 * Performs input validation and calls the usersubDW function to execute the transaction.
 * Displays the transaction details and the updated account balance.
 * @param depositwithdraw An integer indicating the type of operation (1 for deposit, 2 for withdrawal).
 * @param userspointerArray An array of pointers to bankuser_user structures.
 * @param userCount The current number of users in the system.
 */
void userDepositWithdraw(int depositwithdraw, bankuser_user *userspointerArray[], int userCount) {
    char *name;
    int account_id;/*bankaccount_id:1) Chequing Total: 10000.00     2) Saving Total: 500.00   3) ReadLine Total: 0.00*/
    float amount;
    int index;/*account_id-1*/
    int i;
    bool flag;
    bankuser_user *existuser;
    flag=true;

    name = input_name();
    existuser = pbankuser(name, userspointerArray, userCount);

    if (existuser != NULL) {
        printf("Ready to perform %s for user: %s\n", (depositwithdraw == 1) ? "deposit" : "withdrawan", existuser->username[0]);
        printf("Enter your account choice: ");/**************/
        scanf("%d", &account_id);
        printf("Enter %s amount: ",(depositwithdraw == 1) ? "deposit" : "withdrawan");
        scanf("%f", &amount);
        index = account_id-1;
        while(flag){
            if(account_id==3 && depositwithdraw==2 && amount !=0){
                perror("Readline account can not accept withdraw !\n");
                printf("Please only input 1,2 or 3: 1) Chequing 2) Saving 3) ReadLine\n");
                scanf("%d", &account_id);
                printf("Enter %s amount: ",(depositwithdraw == 1) ? "deposit" : "withdrawan");
                scanf("%f", &amount);
                flag = true;
                continue;
            }
            if(amount <=0){
                printf("Enter input a valid amount: ( amount >0 ) ");
                scanf("%f", &amount);
                flag = true;
                continue;
            }
            if(( existuser->pBankAccount[index]->total<amount)&&(depositwithdraw==2)){
                printf("Enter input a valid amount: ( total is not enough ) ");
                scanf("%f", &amount);
                flag = true;
                continue;
            }
            /*if(account_id ==1 || account_id ==2 || amount > 0){
                flag=false;
            }*/
            flag=false;
        }


        if ((account_id >= 1 && account_id <= 3) && amount >= 0) { /*valid account and amount */
            if (usersubDW(depositwithdraw, existuser, account_id-1, amount)) {
                printf("The %s Operation is finished.\n",(depositwithdraw == 1) ? "deposit" : "withdrawan");
                /*print out all transaction recording */
                for (i = 0; i < MAXRECORD; i++) {
                    if (existuser->pBankAccount[index]->pTransaction[i] != NULL && (i == MAXRECORD - 1 || existuser->pBankAccount[index]->pTransaction[i + 1] == NULL)) {
                        printf("This transcation money is %.2f, the time is %s and total is %.2f .\n",
                                   existuser->pBankAccount[index]->pTransaction[i]->amount,
                                   existuser->pBankAccount[index]->pTransaction[i]->timebuffer,
                                   existuser->pBankAccount[index]->total);
                        break;
                    }
                }
            } else {
                printf("The Deposit Operation is failed.\n");
            }
        } else {
            perror("Error:Deposit amount must be positive or account id should be Chequing or Saving.\n");
        }
    } else {
        printf("The input username is invaild.\n");
    }
    free(name);
}

/*
 * Finds a bank user by their username in the provided array of users.
 * Iterates through the array and compares the input name with the username of each user.
 * Prints the user ID and the total balance of their accounts if a match is found.
 * @param name The username to search for.
 * @param userspointerArray An array of pointers to bankuser_user structures.
 * @param userCount The current number of users in the system.
 * @return A pointer to the found bankuser_user structure, or NULL if no matching user is found.
 */
bankuser_user *pbankuser(char *name, bankuser_user *userspointerArray[], int userCount){
    int i=0;
    printf("the current user Num is %d\n", userCount);

    for(i=0;i<userCount;i++){
        if(userspointerArray[i] != NULL && userspointerArray[i]->username[0] != NULL){
            printf("index %d username : %s\n", i, userspointerArray[i]->username[0]); /*print out mutlipy user to test*/
            if (strcmp(userspointerArray[i]->username[0], name) == 0) {
                printf("Find the match user!\n");
                printf("User ID: %d\n", userspointerArray[i]->userid);
                printf("1) Chequing Total: %.2f     2) Saving Total: %.2f   3) ReadLine Total: %.2f\n",
                       userspointerArray[i]->pBankAccount[0]->total,
                       userspointerArray[i]->pBankAccount[1]->total,
                       userspointerArray[i]->pBankAccount[2]->total);
                return userspointerArray[i]; /*returen the user point*/
            }
        }
    }
    return NULL;
}


/*
 * Performs a deposit or withdrawal operation on a specified account for a given user.
 * Creates a new transaction record, updates the account balance and total, and sets the transaction type.
 * Increments the transaction count for the account.
 * @param dwtype An integer indicating the type of operation (1 for deposit, 2 for withdrawal).
 * @param existuser Pointer to the bankuser_user structure of the user.
 * @param account_id The index of the account (0 for Chequing, 1 for Saving, 2 for ReadLine).
 * @param amount The amount to deposit or withdraw.
 * @return A boolean value indicating the success of the operation (always true in this implementation).
 */
bool usersubDW(int dwtype, bankuser_user *existuser,int account_id,float amount){
    int index = account_id;
    int transactionIndex;
    transactionIndex=existuser->pBankAccount[index]->transactionCount;
    existuser->pBankAccount[index]->pTransaction[existuser->pBankAccount[index]->transactionCount] = createTransaction(amount);
    existuser->pBankAccount[index]->pTransaction[existuser->pBankAccount[index]->transactionCount]->amount = amount;


    if (dwtype == 1) {
        existuser->pBankAccount[index]->total += amount;
        existuser->pBankAccount[index]->pTransaction[transactionIndex]->transactiontype=SAVING;
        /*setTransactionType(existuser->pBankAccount[index]->pTransaction[transactionIndex], amount);*/
    } else if (dwtype == 2) {
        existuser->pBankAccount[index]->total -= amount;
        existuser->pBankAccount[index]->pTransaction[transactionIndex]->transactiontype=WITHDRAWN;
        /*setTransactionType(existuser->pBankAccount[index]->pTransaction[transactionIndex], -amount);*/
    }
    printf("The current transaction type is %d,and the true type is %s\n",existuser->pBankAccount[index]->pTransaction[transactionIndex]->transactiontype,getTransactionTypeString(existuser->pBankAccount[index]->pTransaction[transactionIndex]->transactiontype));
    printf("The current transaction count is %d\n",existuser->pBankAccount[index]->transactionCount);
    existuser->pBankAccount[index]->transactionCount++;
    return true;
}

/*
 * Converts a username to its corresponding user ID.
 * Iterates through the array of users and compares the input username.
 * @param username The username to search for.
 * @return The user ID if the username is found, otherwise returns -1.
 */
int usernametoID(char *username){
    char *name;
    int i=0;
    name = username;
    for (i = 0; i < currentuserNum; i++) {
        if (users[i] != NULL) {
            if (strcmp(users[i]->username[0], name) == 0) {
                return users[i]->userid;
            }
        }
    }
    return -1;
}

/*
 * Lists all available users in the system.
 * Iterates through the array of users and prints their index and username.
 */
void userList(){
    int i=0;
    printf("Available accounts are: ");
    for (i = 0; i < currentuserNum; i++) {
        if (users[i] != NULL) {
            printf(" %d) %s     ", i+1,users[i]->username[0]);
        }
    }
    printf("\n");
}

/*
 * Displays the details of a specific user's account.
 * Prompts the user to select a user and then an account type.
 * Calls the userpreprint function to print the account details.
 */
void userDisplay(){

    int choice_user;
    int choice_account;
    userList();
    printf("Enter your account choice: ");
    scanf("%d",&choice_user);
    newUser=users[choice_user-1];
    if (newUser == NULL) {
        printf("The userid %d is unavailable\n", (choice_user-1+5000));
    }else{
        printf("Available accounts are: ");
        if (newUser->pBankAccount!= NULL) {
            printf("1) Chequing     2)Savings.\n");
        }
        printf("Enter your account choice: ");
        scanf("%d",&choice_account);
        userpreprint(newUser,choice_account);
    }

}

/*
 * Prints the account details and transaction history for a selected user and account type.
 * @param newUser Pointer to the bankuser_user structure.
 * @param choice_account An integer representing the user's account type choice (1 for Chequing, 2 for Savings).
 */
void userpreprint(bankuser_user *newUser,int choice_account){
    int i;
    printf("Account Detail for account ID %d :\n",newUser->userid);
    printf("-Name: %s\n",newUser->username[0]);
    printf("-Balance: %f\n",newUser->pBankAccount[choice_account-1]->total);
    printf("-Account Type: %s\n",(choice_account == 1) ? "chequing" : "savings");
    printf("The number of account of transacton:%d\n",newUser->pBankAccount[choice_account-1]->transactionCount);
    printf("-Transaction History:\n");
    for (i = 0; i < MAXRECORD; i++) {
        if (newUser->pBankAccount[choice_account-1]->pTransaction[i] != NULL) {
            printf("- Type: %s, ", getTransactionTypeString(newUser->pBankAccount[choice_account-1]->pTransaction[i]->transactiontype));
            printf("Amount: %.2f, ", newUser->pBankAccount[choice_account-1]->pTransaction[i]->amount);
            printf("Time: %s\n", newUser->pBankAccount[choice_account-1]->pTransaction[i]->timebuffer);
        }
    }
    if (newUser->pBankAccount[choice_account-1]->pTransaction[0] == NULL) {
        printf("  No transaction history yet.\n");
    }

}