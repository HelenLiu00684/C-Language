#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define EXIT_FAILURE 1
#define MAXRECORD 40     /*Define the number of the record*/
#define MAXBANDACCOUNT 3     /*Define the number of the bandaccount*/
#define NUM_USERS 5        /* 定义要创建的用户数量 */

int global_checuing = 0;
int global_saving = 0;
int global_readline = 0;

typedef enum {
    SAVING,
    WITHDRAWN
} TransactionType;

typedef enum {
    CHEQUING,
    SAVINGS,
    READLINE
} AccountType;

typedef struct Transaction {
    TransactionType transactiontype;
    float amount;
    char *timebuffer;
} bankaccount_transaction;

typedef struct BankAccount {
    int baseaccount;
    int subaccountid;
    AccountType accounttype;
    float balance;
    float total;
    time_t timestamp;
    char *creationTimeStr;
    bankaccount_transaction *pTransaction[MAXRECORD];
} bankaccount_account;

typedef struct User {
    int userid;
    char *username[30];
    bankaccount_account *pBankAccount[MAXBANDACCOUNT];
} bankuser_user;

float getRandom(int positive, int negtive);
int getRandomId(int positive, int negtive);
char *input_name();
void setAccountType(bankaccount_account *pbankaccount, int accountType);
void setTransactionType(bankaccount_transaction *ptransaction, float amount);
char *gettime();
bankaccount_transaction *createTransaction(float amount);
bankaccount_account *createBankaccount(int accountType, float amount);
bankuser_user *createBankuser();
const char *getTransactionTypeString(TransactionType type);
const char *getBankaccountTypeString(AccountType type);

char *input_name() {
    char *input_name = (char *)malloc(50 * sizeof(char));
    if (input_name == NULL) {
        perror("Failed to allocate memory");
        return NULL;
    }
    printf("please input your name:");
    if (fgets(input_name, 50, stdin) != NULL) {
        char *ptr = input_name;
        while (*ptr != '\0') {
            if (*ptr == '\n') {
                *ptr = '\0';
                break;
            }
            ptr++;
        }
        printf("you name is :%s\n", input_name);
        return input_name;
    } else {
        printf("reading error\n");
        free(input_name);
        return NULL;
    }
}

char *gettime() {
    char *buffer;
    time_t timer;
    struct tm *tm_info;
    time(&timer);
    buffer = (char *)malloc(40 * sizeof(char));
    if (buffer == NULL) {
        perror("alloc memory failed");
        exit(EXIT_FAILURE);
    }
    tm_info = localtime(&timer);
    strftime(buffer, 40, "%Y-%m-%d %H:%M:%S", tm_info);
    return buffer;
}

bankaccount_transaction *createTransaction(float amount) {
    bankaccount_transaction *ptransaction = (bankaccount_transaction *)malloc(sizeof(bankaccount_transaction));
    if (ptransaction == NULL) {
        perror("Failed to allocate memory for Transaction");
        return NULL;
    }
    ptransaction->amount = amount;
    ptransaction->timebuffer = gettime();
    if (amount > 0) {
        ptransaction->transactiontype = SAVING;
    } else {
        ptransaction->transactiontype = WITHDRAWN;
    }
    return ptransaction;
}

bankaccount_account *createBankaccount(int accountType, float amount) {
    int i = 0;
    bankaccount_account *pbankaccount = (bankaccount_account *)malloc(sizeof(bankaccount_account));
    if (pbankaccount == NULL) {
        perror("Failed to allocate memory for Bankaccount");
        return NULL;
    }
    setAccountType(pbankaccount, accountType);
    pbankaccount->timestamp = time(NULL);
    pbankaccount->creationTimeStr = gettime();
    pbankaccount->balance = amount;
    pbankaccount->total = amount+pbankaccount->total;
    for (i = 0; i < MAXRECORD; i++) {
        pbankaccount->pTransaction[i] = NULL; /*Initialize to NULL*/
    }
    return pbankaccount;
}

bankuser_user *createBankuser(){
    char *name;
    bankuser_user *puser = (bankuser_user *)malloc(sizeof(bankuser_user));
    int i;
    if (puser == NULL) {
        perror("Failed to allocate memory for User");
        return NULL;
    }

    name = input_name();
    if (name == NULL) {
        free(puser);
        return NULL;
    }

        /*为 username[0] 分配内存并将 name 复制进去*/
        puser->username[0] = (char *)malloc(strlen(name) + 1);
        if (puser->username[0] == NULL) {
            perror("Failed to allocate memory for username");
            free(name);
            free(puser);
            return NULL;
        }
        strcpy(puser->username[0], name);
        free(name); /*释放 input_name 函数中分配的内存*/

    puser->pBankAccount[0] = createBankaccount(CHEQUING, 100.0f); /*创建支票账户*/
    if (puser->pBankAccount[0] == NULL) {
        perror("Failed to create CHEQUING account");
        free(puser);
        return NULL;
    }

    puser->pBankAccount[1] = createBankaccount(SAVINGS, 1000.0f); /*创建储蓄账户*/
    if (puser->pBankAccount[1] == NULL) {
        perror("Failed to create SAVINGS account");
        free(puser->pBankAccount[0]);
        free(puser);
        return NULL;
    }

    puser->pBankAccount[2] = createBankaccount(READLINE, 0.0f);   /*创建透支账户*/
    if (puser->pBankAccount[2] == NULL) {
        perror("Failed to create READLINE account");
        free(puser->pBankAccount[0]);
        free(puser->pBankAccount[1]);
        free(puser);
        return NULL;
    }

    puser->userid = getRandomId(100,0)+5000; /*示例用户ID，您可以根据需要修改*/

    return puser;
}

void setTransactionType(bankaccount_transaction *ptransaction, float amount) {
    ptransaction->amount = amount;
    ptransaction->transactiontype = (amount > 0) ? SAVING : WITHDRAWN;
}

void setAccountType(bankaccount_account *pbankaccount, int accountType) {
    pbankaccount->accounttype = accountType;
    if (accountType == 0) {
        pbankaccount->accounttype = CHEQUING;
        pbankaccount->baseaccount = 1000;
        pbankaccount->subaccountid = global_checuing++;
    } else if (accountType == 1) {
        pbankaccount->accounttype = SAVINGS;
        pbankaccount->baseaccount = 2000;
        pbankaccount->subaccountid = global_saving++;
    } else if (accountType == 2) {
        pbankaccount->accounttype = READLINE;
        pbankaccount->baseaccount = 3000;
        pbankaccount->subaccountid = global_readline++;
    }
}

const char *getTransactionTypeString(TransactionType type) {
    switch (type) {
        case SAVING:
            return "saving";
        case WITHDRAWN:
            return "withdrawn";
        default:
            return "unknown";
    }
}

const char *getBankaccountTypeString(AccountType type) {
    switch (type) {
        case CHEQUING:
            return "chequing";
        case SAVINGS:
            return "saving";
        case READLINE:
            return "readline";
        default:
            return NULL;
    }
}

float getRandom(int positive, int negtive) {
    double random_float;
    random_float = (double)rand() / RAND_MAX * positive - negtive;
    return random_float;
}

int getRandomId(int positive, int negtive) {
    int random_int;
    random_int = (int)rand() / RAND_MAX * positive - negtive;
    return random_int;
}

int main(void) {
    int i, j, k;
    bankuser_user *users[NUM_USERS];

    /*创建 NUM_USERS 个用户*/ 
    for (i = 0; i < NUM_USERS; i++) {
        printf("\nCreating user %d:\n", i + 1);
        users[i] = createBankuser();
        if (users[i] == NULL) {
            printf("Failed to create user %d.\n", i + 1);
            /*可以选择在这里添加错误处理，例如退出程序*/ 
        }
    }

    /*遍历每个用户，并打印其信息和银行账户信息*/ 
    for (i = 0; i < NUM_USERS; i++) {
        if (users[i] != NULL) {
            printf("\n----- User Information for User %d -----:\n", i + 1);
            printf("User ID: %d\n", users[i]->userid);
            printf("Username: %s\n", users[i]->username[0]);

            printf("\nBank Accounts and Transactions:\n");
            for (k = 0; k < MAXBANDACCOUNT; k++) {
                if (users[i]->pBankAccount[k] != NULL) {
                    printf("\nAccount [%d] - AccountID: %d, Type: %s, Creation Time: %s, Balance: %.2f\n",
                           k + 1,
                           users[i]->pBankAccount[k]->baseaccount + users[i]->pBankAccount[k]->subaccountid,
                           getBankaccountTypeString(users[i]->pBankAccount[k]->accounttype),
                           users[i]->pBankAccount[k]->creationTimeStr,
                           users[i]->pBankAccount[k]->balance);

                    printf("  Generating 40 transactions for this account:\n");
                    for (j = 0; j < MAXRECORD; j++) {
                        float random_amount = getRandom(500, -500);
                        users[i]->pBankAccount[k]->pTransaction[j] = createTransaction(random_amount);
                        if (users[i]->pBankAccount[k]->pTransaction[j] != NULL) {
                            printf("    Transaction %d - Amount: %.2f, Type: %s, Time: %s\n",
                                   j + 1,
                                   users[i]->pBankAccount[k]->pTransaction[j]->amount,
                                   getTransactionTypeString(users[i]->pBankAccount[k]->pTransaction[j]->transactiontype),
                                   users[i]->pBankAccount[k]->pTransaction[j]->timebuffer);
                        } else {
                            printf("    Failed to create transaction %d.\n", j + 1);
                        }
                    }
                    free(users[i]->pBankAccount[k]->creationTimeStr);
                    for (j = 0; j < MAXRECORD; j++) {
                        if (users[i]->pBankAccount[k]->pTransaction[j] != NULL) {
                            free(users[i]->pBankAccount[k]->pTransaction[j]->timebuffer);
                            free(users[i]->pBankAccount[k]->pTransaction[j]);
                        }
                    }
                    free(users[i]->pBankAccount[k]);
                } else {
                    printf("Account [%d] is NULL for user %d.\n", k + 1, i + 1);
                }
            }
            if (users[i]->username[0] != NULL) {
                free(users[i]->username[0]);
            }
            free(users[i]);
        }
    }

    return 0;
}