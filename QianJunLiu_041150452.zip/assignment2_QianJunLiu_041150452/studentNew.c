#include <stdio.h>
#include <stdlib.h>
#include "studentNew.h"

/*Function to read the binary file, create student objects, and build a linked list*/ 
student_stu* createStudentListFromFile(const char *filename) {
    FILE *fp;
    student_read student_data; 
    size_t bytes_read;
    student_stu* head = NULL;
    student_stu* tail = NULL; 
    int i=0;

    fp = fopen(filename, "rb");
    if (fp == NULL) {
        perror("Error opening binary file for reading");
        return NULL;
    }

    printf("Reading contents of the binary file '%s' and creating linked list:\n", filename);
    while ((bytes_read = fread(&student_data, sizeof(student_read), 1, fp)) > 0) {
        student_stu* newStudent = createStudent(student_data.studentID, student_data.marks);
        if (newStudent == NULL) {
            fclose(fp);
            freeStudentList(head);
            return NULL;
        }

        if (head == NULL) {
            head = newStudent;
            tail = newStudent;
        } else {
            tail->next = newStudent;
            newStudent->prev = tail;
            tail = newStudent;
        }
        printf("Index: %d, Read StudentID: %d, Mark: %.2f and inserted into list.\n", i++, newStudent->sid, newStudent->marks);
    }

    if (ferror(fp)) {
        perror("Error reading from binary file");
        freeStudentList(head);
        fclose(fp);
        return NULL;
    }

    fclose(fp);
    printf("Finished reading binary file and creating linked list.\n");
    return head;
}


/* Function to save the linked list of students to a binary file */
int saveStudentListToFile(student_stu* head, const char *filename) {
    FILE *fp;
    student_read student_record;
    /*student_read student_record;*/
    student_stu* current = head;
    size_t bytes_written;
    int i=0;

    /* Open the file in write binary mode */ 
    fp = fopen(filename, "wb");
    if (fp == NULL) {
        perror("Error opening binary file for writing");
        return -1; /* Return error code */ 
    }

    printf("Saving contents of the linked list to the binary file '%s':\n", filename);

    /* Traverse the linked list */ 
    while (current != NULL) {
        /* Copy data from the linked list node to the file record structure */ 
        student_record.studentID = current->sid;
        student_record.marks = current->marks;


        /* Write the student record to the file */ 
        bytes_written = fwrite(&student_record, sizeof(student_read), 1, fp);
        if (bytes_written != 1) {
            perror("Error writing to binary file");
            fclose(fp);
            return -1; /* Return error code */ 
        }
        /*printf("Index: %d, Saved StudentID: %d, Mark: %.2f to file.\n", i++,student_record.studentID, student_record.marks);*/
        current = current->next;
    }

    fclose(fp);
    printf("Finished saving linked list to binary file '%s'.\n", filename);
    return 0; /* Return success code */ 
}

void saveStudentList(student_stu* student_list_head) {
    const char *output_filename = "output.dat"; 
    if (saveStudentListToFile(student_list_head, output_filename) == 0) {
        printf("Student list saved successfully to %s\n", output_filename);
    } else {
        fprintf(stderr, "Failed to save student list to %s\n", output_filename);
    }
}

student_stu *createStudent(int studentid, double mark){
    student_stu* newStudent;
    newStudent=(student_stu *)malloc(sizeof(student_stu));
    if (newStudent == NULL) {
        /*if malloc has error, return error messag*/ 
        fprintf(stderr, "Error: Memory allocation failed\n");
        exit(ALLOCATE_MEMORY_ERROR);
    }
    newStudent->sid=studentid;
    newStudent->marks=mark;
    newStudent->next=NULL;
    newStudent->prev=NULL;
    return newStudent;
}

/*free the entire linked list*/
void freeStudentList(student_stu* head) {
    student_stu* current = head;
    student_stu* next;
    while (current != NULL) {
        next = current->next;
        free(current);
        current = next;
    }
}

/* Function to insert a node at the end */ 
int insertStudentEnd(student_stu** stuhead, int studentid, double mark){
    student_stu* stuTemp;
    /*creating new student*/ 
    student_stu *newStudent;
    newStudent = createStudent(studentid,mark);
    stuTemp = *stuhead;     /*Only one node set head for newStudent;*/ 

    /*check if DLL is empty*/
    if(*stuhead == NULL){
        *stuhead = newStudent;
        return ALLOCATE_MEMORY_ERROR;
    }

    while (stuTemp->next != NULL) {
        stuTemp = stuTemp->next;
    }
    stuTemp->next = newStudent;
    newStudent->prev = stuTemp;
    return 0;
}

/*Count the number of node in Linklist*/
int countListForward(student_stu** stuhead){
    /**
     * Function Definition:
     * - `stuhead`: A pointer to a pointer to the head of the student information linked list.
     * - Return Value: The number of nodes in the linked list.
     */
    student_stu* stuTemp;
    int number;
    number = 0;
    stuTemp = *stuhead; /* Correctly initialize stuTemp to the head of the list */ 
    /**
     * Initialization:
     * - `stuTemp`: A temporary pointer to a `student_stu` node, used for traversing the list.
     * - `number`: An integer variable to store the count of nodes, initialized to 0.
     */
    while (stuTemp != NULL) {
        stuTemp = stuTemp->next;
        number ++;
    }
    /**
     * Counting Loop:
     * - This `while` loop iterates through the list as long as `stuTemp` is not NULL.
     * - `stuTemp = stuTemp->next;`: Moves `stuTemp` to the next node in the list.
     * - `number ++;`: Increments the `number` counter for each node visited.
     */
    return number;
}
/*Function to find a node position at the linklist then print out the one*/
void printLinkedList(student_stu** stuhead, int indexStu){
    /**
     * Function Definition:
     * - `stuhead`: A pointer to a pointer to the head of the student information linked list.
     * - `indexStu`: The index of the node whose data needs to be printed.
     * - Return Value: void (does not return any value).
     */
    int index;
    int size;
    student_stu* stuTemp;

    /**
     * Initialization:
     * - `index`: Used to keep track of the current node's index during list traversal.
     * - `size`: Stores the total length of the linked list.
     * - `stuTemp`: A temporary pointer to a `student_stu` node, used for traversing the list.
     */
    index = 0;
    size = countListForward(stuhead);

    if(*stuhead==NULL){
        fprintf(stderr, "Error: The link list is empty.\n");
        return;
    }

    /**
     * Empty List Check:
     * - If the head pointer of the list `*stuhead` is NULL, it means the list is empty.
     * - Prints an error message to the standard error stream `stderr`.
     * - Returns from the function as there is nothing to print.
     */

    if(indexStu>=size||indexStu<0){
        printf("Error: The parameter is wrong.\n");
        return;
    }

    /**
     * Index Range Check:
     * - Checks if `indexStu` is within the valid index range (0 to `size - 1`).
     * - If `indexStu` is out of range, prints an error message to the standard output stream `stdout`.
     * - Returns from the function.
     */

    stuTemp = *stuhead;
    while (stuTemp != NULL && index < indexStu) {
        stuTemp = stuTemp->next;
        index++;
    }

    /**
     * Traverse to the Node:
     * - Initializes `stuTemp` to the head of the list.
     * - Uses a `while` loop to traverse the list until the node at the specified `indexStu` is reached.
     * - `stuTemp = stuTemp->next;`: Moves `stuTemp` to the next node.
     * - `index++`: Increments the index counter.
     */

    if (stuTemp != NULL && index == indexStu) {
        printf("Index: %d,  StudentID: %d,      StudentMark: %.2f\n", indexStu,stuTemp->sid,stuTemp->marks);
    } else {
        printf("Error: Could not find student at index %d.\n", indexStu);
    }

    /**
     * Print Node Data:
     * - Checks if `stuTemp` is not NULL (meaning the node was found) and the index matches `indexStu`.
     * - Prints a message indicating the index.
     * - **Important**: The line `printf("Data - You need to define how to print student_stu data\n");` is a placeholder. You need to replace this with the actual way you want to print the data of a `student_stu` node (e.g., print `stuTemp->studentId`, `stuTemp->name`, etc., depending on the structure definition).
     * - If the node was not found (which shouldn't happen given the size check at the beginning, but it's a good safety measure), it prints an error message.
     */
}

/* Function to find a node position at the linklist */
int delindexStudent(student_stu** stuhead, int indexStu){
    /**
     * Function Definition:
     * - `stuhead`: A pointer to a pointer to the head of the student information linked list. This allows the function to modify the head of the list.
     * - `indexStu`: The index of the node to be deleted from the linked list.
     * - Return Value: 0 indicates success, other values indicate an error.
     */
    int index;
    int size;
    student_stu* stuTemp;

    index = 0;
    size = countListForward(stuhead);


    /**
     * Initialization:
     * - `index`: Used to keep track of the current node's index during list traversal.
     * - `size`: Stores the total length of the linked list, obtained by calling the `countListForward` function.
     * - `stuTemp`: A temporary pointer to a `student_stu` node, used for traversing the list.
     * - `prevNode`: A pointer to the node preceding `stuTemp`, initialized to `NULL`.
     */

    if(*stuhead==NULL){
        fprintf(stderr, "Error: The link list is empty.\n");
        return PARAM_OUT_OF_RANGE;
    }

    /**
     * Empty List Check:
     * - If the head pointer of the list `*stuhead` is NULL, it means the list is empty.
     * - Prints an error message to the standard error stream `stderr`.
     * - Returns `PARAM_OUT_OF_RANGE`, indicating that the parameter is out of range (as no deletion can be performed on an empty list).
     */

    if(indexStu>=size||indexStu<0){
        printf("Error: The parameter is wrong.\n");
        return PARAM_OUT_OF_RANGE;
    }

    /**
     * Index Range Check:
     * - Checks if `indexStu` is within the valid index range (0 to `size - 1`).
     * - If `indexStu` is out of range, prints an error message to the standard output stream `stdout`.
     * - Returns `PARAM_OUT_OF_RANGE`.
     */

    stuTemp = *stuhead;

    /**
     * Initialize stuTemp to the head of the list.
     */


    if(indexStu==0){
        *stuhead=stuTemp->next;
        if (*stuhead != NULL) {
            (*stuhead)->prev = NULL;
        }
        printf("Delete header node.\n");
        free(stuTemp);
        return 0;
    }

    /**
     * Delete Header Node:
     * - If `indexStu` is 0, it means the head node needs to be deleted.
     * - `*stuhead=stuTemp->next;`: Updates the head pointer to the next node in the list.
     * - `if (*stuhead != NULL) { (*stuhead)->prev = NULL; }`: If the new head is not NULL, sets its `prev` pointer to `NULL`.
     * - Prints a message indicating that the header node has been deleted.
     * - `free(stuTemp);`: Releases the memory occupied by the original head node.
     * - Returns 0 to indicate successful deletion.
     */


    while(stuTemp != NULL && index < size){
        if(index == indexStu){
            if(stuTemp->prev != NULL){
                stuTemp->prev->next = stuTemp->next;
            }
            if(stuTemp->next != NULL){
                stuTemp->next->prev = stuTemp->prev;
            }
            free(stuTemp);
            return 0;
        }

        stuTemp = stuTemp->next; /* Move to NextNode;*/
        index++;
    }

    /**
     * Delete Middle or Tail Nodes:
     * - This `while` loop iterates through the list to find the node at the specified `indexStu`.
     * - `if(index == indexStu)`: Checks if the current node's index matches `indexStu`.
     * - `if(stuTemp->prev != NULL) { stuTemp->prev->next = stuTemp->next; }`: If the node to be deleted is not the head, sets the `next` pointer of the previous node to the next node of the node to be deleted.
     * - `if(stuTemp->next != NULL) { stuTemp->next->prev = stuTemp->prev; }`: If the node to be deleted is not the tail, sets the `prev` pointer of the next node to the previous node of the node to be deleted.
     * - `free(stuTemp);`: Releases the memory occupied by the deleted node.
     * - Returns 0 to indicate successful deletion.
     * - `prevNode = stuTemp;`: Stores the current node as the previous node for the next iteration.
     * - `stuTemp = stuTemp->next;`: Moves `stuTemp` to the next node in the list.
     * - `index++;`: Increments the index counter.
     */

    return -1; 
}

/*Function to find a node position at the linklist the swap to the preview*/ 
int pshindexStudent(student_stu** stuhead, int indexStu) {
    /* Function Definition:
     * `stuhead`: A pointer to a pointer to the head of the student information linked list. This allows the function to modify the head of the list.
     * `indexStu`: The index of the node that needs to be moved one position forward (towards the beginning of the list).
     * Return Value: 0 indicates success, other values indicate an error.
     */
    int index;
    int size;

    student_stu* beforePrevNode;
    student_stu* prevNode;
    student_stu* node;
    student_stu* nextNode;

    index = 0;
    size = countListForward(stuhead); 

        /* Initialization:
     * `index`: Used to keep track of the current node's index during list traversal.
     * `size`: Stores the total length of the linked list, obtained by calling the `countListForward` function.
     * `beforePrevNode`, `prevNode`, `node`, `nextNode`: These are pointers to list nodes used to temporarily store the positions of relevant nodes during the swap operation.
     */

    if (*stuhead == NULL) {
        fprintf(stderr, "Error: The link list is empty.\n");
        return PARAM_OUT_OF_RANGE;
    }

    /* Empty List Check:
     * If the head pointer of the list `*stuhead` is NULL, it means the list is empty.
     * Prints an error message to the standard error stream `stderr`.
     * Returns `PARAM_OUT_OF_RANGE`, indicating that the parameter is out of range (as no operation can be performed on an empty list).
     */

    if (indexStu >= size || indexStu < 0) {
        printf("Error: The parameter is wrong.\n");
        return PARAM_OUT_OF_RANGE;
    }

    /* Index Range Check:
     * Checks if `indexStu` is within the valid index range (0 to `size - 1`).
     * If `indexStu` is out of range, prints an error message to the standard output stream `stdout`.
     * Returns `PARAM_OUT_OF_RANGE`.
     */

    if (indexStu == 0) {
        return 0; /* Index = 0 can not remove forward */ 
    }

    /* Handling the case where the index is 0:
     * If `indexStu` is 0, it means the first node of the list is to be moved.
     * Since the first node does not have a preceding node, it cannot be moved forward.
     * The function directly returns 0, indicating that no operation is needed in this case.
     */

    node = *stuhead;    
    while (node != NULL && index < indexStu) {
        node = node->next;
        index++;
    }

    /* Finding the Target Node:
     * Starts from the head of the list (`node = *stuhead`).
     * Uses a `while` loop to traverse the list until the node at the specified `indexStu` is found.
     * `node = node->next`: Moves the `node` pointer to the next node in the list.
     * `index++`: Increments the current node's index count.
     * The loop will terminate in two scenarios:
     * 1. `node` becomes `NULL`, indicating the end of the list has been reached.
     * 2. `index` equals `indexStu`, indicating that the target node has been found.
     */

    /* Check find the current node. */
    if (node == NULL || index != indexStu) {
        fprintf(stderr, "Error: Index out of bounds during search.\n");
        return PARAM_OUT_OF_RANGE; 
    }

    /* Checking if the target node was successfully found:
     * If after the loop, `node` is `NULL` or `index` is not equal to `indexStu`, it indicates an issue during traversal, possibly because `indexStu` was beyond the actual bounds of the list.
     * Prints an error message and returns `PARAM_OUT_OF_RANGE`.
     */

    /* Important Note: At this point, `node` points to the node that needs to be moved one position forward.
     * However, `prevNode` has not been assigned a value yet. This is a potential error in your original code.
     * `prevNode` is used when handling the second and middle nodes, but it should be assigned after finding `node`.
     */

    /* Should be added here: */

    /* Assigning relevant pointers:
     * `prevNode = node->prev;`: Assigns `prevNode` to the node preceding `node`.
     * `beforePrevNode = prevNode->prev;`: Assigns `beforePrevNode` to the node preceding `prevNode`.
     * `nextNode = node->next;`: Assigns `nextNode` to the node following `node`.
     * Note: If `node` is the second node in the list, then `beforePrevNode` will be `NULL`.
     */

    prevNode = node->prev;
    beforePrevNode = prevNode->prev;
    nextNode = node->next;
    if (prevNode == NULL) {
        fprintf(stderr, "Error: Previous node is NULL for indexStu > 0.\n");
        return INVALID_NUMBER_ARGUMENTS; 
    }



    /* The second node */
    /* Handling the second node (index is 1):
     * `if (indexStu == 1)`: Checks if the node to be moved is the second node in the list.
     * `prevNode->next = nextNode;`: Sets the `next` pointer of the original head node (`prevNode`) to the node following `node` (`nextNode`).
     * `if (nextNode != NULL) { nextNode->prev = prevNode; }`: If `node` is not the second to last node, sets the `prev` pointer of `nextNode` to the original head node (`prevNode`).
     * `node->prev = NULL;`: Sets the `prev` pointer of `node` to `NULL` because `node` will become the new head of the list.
     * `node->next = prevNode;`: Sets the `next` pointer of `node` to the original head node (`prevNode`).
     * `prevNode->prev = node;`: Sets the `prev` pointer of the original head node (`prevNode`) to `node`.
     * `*stuhead = node;`: **Crucial Step**: Updates the head pointer of the list to point to the new head node (`node`).
     * `return 0;`: Returns 0 to indicate successful operation.
     */
    if (indexStu == 1) {
        prevNode->next = nextNode;
        if (nextNode != NULL) {
            nextNode->prev = prevNode;
        }
        node->prev = NULL;
        node->next = prevNode;
        prevNode->prev = node;
        *stuhead = node; /* update the header */
        return 0;
    }

    /**
     * Handling a middle node (index greater than 1):
     * `if (beforePrevNode != NULL)`: Checks if `node` is a middle node (meaning there are at least two nodes before it).
     * `beforePrevNode->next = node;`: Sets the `next` pointer of the node before the previous node (`beforePrevNode`) to `node`.
     * `node->prev = beforePrevNode;`: Sets the `prev` pointer of `node` to the node before the previous node (`beforePrevNode`).
     * `node->next = prevNode;`: Sets the `next` pointer of `node` to its original preceding node (`prevNode`).
     * `prevNode->prev = node;`: Sets the `prev` pointer of the original preceding node (`prevNode`) to `node`.
     * `prevNode->next = nextNode;`: Sets the `next` pointer of the original preceding node (`prevNode`) to the original next node of `node` (`nextNode`).
     * `if (nextNode != NULL) { nextNode->prev = prevNode; }`: If `node` was not the last node, sets the `prev` pointer of `nextNode` to `prevNode`.
     * `return 0;`: Returns 0 to indicate successful operation.
     */
    if (beforePrevNode != NULL) {
        beforePrevNode->next = node;
        node->prev = beforePrevNode;
        node->next = prevNode;
        prevNode->prev = node;
        prevNode->next = nextNode;
        if (nextNode != NULL) {
            nextNode->prev = prevNode;
        }
        return 0;
    }

    return -1; /*return Error Code*/ 
}

/*Function to find a node position at the linklist the swap to the later one*/
int pulindexStudent(student_stu** stuhead, int indexStu){
    /* Function Definition:
     * `stuhead`: A pointer to a pointer to the head of the student information linked list. This allows the function to modify the head of the list.
     * `indexStu`: The index of the node that needs to be moved one position backward (towards the end of the list).
     * Return Value: 0 indicates success, other values indicate an error.
     */
    int index;
    int size;

    student_stu* beforeNode;
    student_stu* node;
    student_stu* nextNode;
    student_stu* afterNextNode;

    index = 0;
    size = countListForward(stuhead); 

    /* Initialization:
     * `index`: Used to keep track of the current node's index during list traversal.
     * `size`: Stores the total length of the linked list, obtained by calling the `countListForward` function.
     * `beforeNode`, `node`, `nextNode`, `afterNextNode`: These are pointers to list nodes used to temporarily store the positions of relevant nodes during the swap operation.
     */

    if (*stuhead == NULL) {
        fprintf(stderr, "Error: The link list is empty.\n");
        return PARAM_OUT_OF_RANGE;
    }

    /* Empty List Check:
     * If the head pointer of the list `*stuhead` is NULL, it means the list is empty.
     * Prints an error message to the standard error stream `stderr`.
     * Returns `PARAM_OUT_OF_RANGE`, indicating that the parameter is out of range (as no operation can be performed on an empty list).
     */

    if (indexStu >= size || indexStu < 0) {
        printf("Error: The parameter is wrong.\n");
        return PARAM_OUT_OF_RANGE;
    }

    /* Index Range Check:
     * Checks if `indexStu` is within the valid index range (0 to `size - 1`).
     * If `indexStu` is out of range, prints an error message to the standard output stream `stdout`.
     * Returns `PARAM_OUT_OF_RANGE`.
     */

    if (indexStu == size - 1) {
        return 0; /*Index = size - 1 can not remove backward*/ 
    }

    /* Handling the case where the index is the last element:
     * If `indexStu` is `size - 1`, it means the node is already at the end of the list.
     * Therefore, it cannot be moved further backward.
     * The function directly returns 0, indicating that no operation is needed in this case.
     */

    node = *stuhead;
    while (node != NULL && index < indexStu) {
        node = node->next;
        index++;
    }

    /* Finding the Target Node:
     * Starts from the head of the list (`node = *stuhead`).
     * Uses a `while` loop to traverse the list, until the node at the specified `indexStu` is found.
     * `node = node->next`: Moves the `node` pointer to the next node in the list.
     * `index++`: Increments the current node's index count.
     * The loop will terminate when `index` equals `indexStu`.
     */

    /* Check find the current node. */
    if (node == NULL || index != indexStu) {
        fprintf(stderr, "Error: Index out of bounds during search.\n");
        return PARAM_OUT_OF_RANGE; 
    }

    /* Checking if the target node was successfully found. */

    beforeNode = node->prev;
    nextNode = node->next;
    if (nextNode == NULL) {
        fprintf(stderr, "Error: Next node is NULL, cannot move backward.\n");
        return -1; 
    }
    afterNextNode = nextNode->next;

    /* Assigning relevant pointers:
     * `beforeNode = node->prev;`: Assigns `beforeNode` to the node preceding `node`.
     * `nextNode = node->next;`: Assigns `nextNode` to the node following `node`.
     * `afterNextNode = nextNode->next;`: Assigns `afterNextNode` to the node following `nextNode`.
     */

    /**
     * Handling the case of moving the second to last node to the last position:
     * - `if (indexStu == size - 2)`: Checks if the node to be moved is the second to last node in the list.
     * - `node->next = afterNextNode;`: Sets the `next` pointer of the second to last node (`node`) to the node after the last node (`afterNextNode`, which will be NULL).
     * - `if (afterNextNode != NULL) { afterNextNode->prev = node; }`: If there is a node after the next node (which shouldn't happen for the true second to last), set its `prev` pointer to `node`. This is a safety check.
     * - `node->prev = nextNode;`: Sets the `prev` pointer of the second to last node (`node`) to the last node (`nextNode`).
     * - `nextNode->next = node;`: Sets the `next` pointer of the last node (`nextNode`) to the second to last node (`node`).
     * - `nextNode->prev = beforeNode;`: Sets the `prev` pointer of the last node (`nextNode`) to the node before the second to last node (`beforeNode`).
     * - `if (beforeNode != NULL) { beforeNode->next = nextNode; }`: If the second to last node was not the head, set the `next` pointer of the node before it (`beforeNode`) to the last node (`nextNode`).
     * - `else { *stuhead = nextNode; }`: If the second to last node was the head, update the head of the list to be the last node (`nextNode`).
     * - `return 0;`: Returns 0 to indicate successful operation.
     */
    if (indexStu == size - 2) {
        node->next = afterNextNode;
        if (afterNextNode != NULL) {
            afterNextNode->prev = node;
        }
        node->prev = nextNode;
        nextNode->next = node;
        nextNode->prev = beforeNode;
        if (beforeNode != NULL) {
            beforeNode->next = nextNode;
        } else {
            *stuhead = nextNode; /*Update head if the moved node was the second node*/ 
        }
        return 0;
    }

    /**
     * Handling a middle node (not the last or second to last):
     * - `if (nextNode != NULL && afterNextNode != NULL)`: Checks if there is a node after the current node (`nextNode`) and a node after that (`afterNextNode`), ensuring it's a middle node.
     * - `node->next = afterNextNode;`: Sets the `next` pointer of the current node (`node`) to the node after the next node (`afterNextNode`).
     * - `if (afterNextNode != NULL) { afterNextNode->prev = node; }`: If there is a node after the next node, set its `prev` pointer to the current node (`node`).
     * - `node->prev = nextNode;`: Sets the `prev` pointer of the current node (`node`) to the next node (`nextNode`).
     * - `nextNode->next = node;`: Sets the `next` pointer of the next node (`nextNode`) to the current node (`node`).
     * - `nextNode->prev = beforeNode;`: Sets the `prev` pointer of the next node (`nextNode`) to the node before the current node (`beforeNode`).
     * - `if (beforeNode != NULL) { beforeNode->next = nextNode; }`: If there is a node before the current node, set its `next` pointer to the next node (`nextNode`).
     * - `else { *stuhead = nextNode; }`: If the current node was the head (which shouldn't happen based on the index check), update the head to the next node. This is a safety net.
     * - `return 0;`: Returns 0 to indicate successful operation.
     */
    if (nextNode != NULL && afterNextNode != NULL) {
        node->next = afterNextNode;
        if (afterNextNode != NULL) {
            afterNextNode->prev = node;
        }
        node->prev = nextNode;
        nextNode->next = node;
        nextNode->prev = beforeNode;
        if (beforeNode != NULL) {
            beforeNode->next = nextNode;
        } else {
            *stuhead = nextNode; /* Update head if the moved node was the first node (which shouldn't happen based on index check) */ 
        }
        return 0;
    }

    return -1; /* return Error Code */
}

