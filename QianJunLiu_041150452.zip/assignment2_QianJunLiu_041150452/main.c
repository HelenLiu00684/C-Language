#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "studentNew.h"

int main(int argc, char *argv[]) {
    const char *binary_filename;
    const char *command;
    const char *param_str;
    int parameter;
    student_stu* student_list_head;
    int student_size;
    int i;

    student_list_head = NULL;
    binary_filename = argv[1];

    /* Read the binary file and create the linked list 
    student_list_head = createStudentListFromFile(binary_filename);*/ 
    
    /* The number of paramert can not less than 2.*/
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <binary_file> [command parameter] ...\n", argv[0]);
        return 1;
    }

    /* Extract and display commands and parameters (rest of your main function) */ 
    printf("\nProcessing commands and parameters:\n");
    for (i = 2; i < argc; i += 2) {
        if (i + 1 < argc) {
            command = argv[i];
            param_str = argv[i + 1];
            parameter = atoi(param_str);    
            printf("Command: %s, Parameter: %d\n", command, parameter);



            
            if(strcmp(command,"add")==0){
                /* Read the binary file and create the linked list */ 
                student_list_head = createStudentListFromFile(binary_filename);

                printf("Inserting students at the end of the loaded list...\n");
                insertStudentEnd(&student_list_head, parameter, 0.0); /* Using student_list_head */ 
                /* printf("\nPrinting the updated linked list (including newly inserted):\n");
                student_size = countListForward(&student_list_head);
                for (i = 0; i < student_size; i++) {
                    printLinkedList(&student_list_head, i);
                } */
                saveStudentList(student_list_head);
                freeStudentList(student_list_head); /* Using student_list_head */ 
                student_list_head = NULL; /* Set head to NULL after freeing */
                printf("\nLinked list memory freed.\n");
            }else if(strcmp(command,"del")==0){
                /* Read the binary file and create the linked list */ 
                student_list_head = createStudentListFromFile(binary_filename);

                printf("Deleting students in the index of the loaded list...\n");
                delindexStudent(&student_list_head, parameter); /* Using student_list_head */ 
                /* printf("\nPrinting the updated linked list (including newly deleted):\n");
                student_size = countListForward(&student_list_head);
                for (i = 0; i < student_size; i++) {
                    printLinkedList(&student_list_head, i);
                } */
                saveStudentList(student_list_head);
                freeStudentList(student_list_head); /* Using student_list_head */ 
                student_list_head = NULL; /* Set head to NULL after freeing */
                printf("\nLinked list memory freed.\n");
            }else if(strcmp(command,"psh")==0){
                /* Read the binary file and create the linked list */ 
                student_list_head = createStudentListFromFile(binary_filename);

                printf("Push the entry with the index of the loaded list forward...\n");
                pshindexStudent(&student_list_head, parameter); /* Using student_list_head */ 
                /* printf("\nPrinting the updated linked list (including newly deleted):\n");
                student_size = countListForward(&student_list_head);
                for (i = 0; i < student_size; i++) {
                    printLinkedList(&student_list_head, i);
                } */
                saveStudentList(student_list_head);
                freeStudentList(student_list_head); /* Using student_list_head */ 
                student_list_head = NULL; /* Set head to NULL after freeing */
                printf("\nLinked list memory freed.\n");
            }else if(strcmp(command,"pul")==0){
                /* Read the binary file and create the linked list */ 
                student_list_head = createStudentListFromFile(binary_filename);

                printf("Pull the entry with the index of the loaded list backward...\n");
                pulindexStudent(&student_list_head, parameter); /* Using student_list_head */ 
                /* printf("\nPrinting the updated linked list (including newly deleted):\n");
                student_size = countListForward(&student_list_head);
                for (i = 0; i < student_size; i++) {
                    printLinkedList(&student_list_head, i);
                } */
                saveStudentList(student_list_head);
                freeStudentList(student_list_head); /* Using student_list_head */ 
                student_list_head = NULL; /* Set head to NULL after freeing */
                printf("\nLinked list memory freed.\n");
            }else if(strcmp(command,"prn")==0){
                /* Read the binary file and create the linked list */ 
                student_list_head = createStudentListFromFile(binary_filename);

                printf("Print the entry with the index of the loaded list backward...\n");
                printLinkedList(&student_list_head, parameter);
                freeStudentList(student_list_head); /* Using student_list_head */ 
                student_list_head = NULL; /* Set head to NULL after freeing */
                printf("\nLinked list memory freed.\n");
            }else{
                perror("Error: Missing parameter for command \n");                
            }
        } else {
            fprintf(stderr, "Error: Missing parameter for command '%s'\n", argv[i]);
        }
    }
    return 0;
}