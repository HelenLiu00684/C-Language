/*  
 * Author: QianJunLiu
 * Number: 041150452  
 * Date: 06-04-2025  
 * Course: CST8234 
 * Project: assignment2  
 */
#define ALLOCATE_MEMORY_ERROR 1
#define OPENING_READING_ERROR 2 
#define INVALID_NUMBER_ARGUMENTS 3
#define PARAM_OUT_OF_RANGE 4
#define ISSUES_WITH_OUTPUT 5



typedef struct Student {
    struct Student* next;
    struct Student* prev;
    int sid;
    double marks;
} student_stu;


typedef struct Studentread {
    int studentID;
    double marks;
}student_read;


student_stu *createStudent(int studentid, double mark);
int insertStudentEnd(student_stu** stuhead, int studentid, double mark);
int delindexStudent(student_stu** stuhead, int indexStu);
int countListForward(student_stu** stuhead);
int pshindexStudent(student_stu** stuhead, int indexStu);
int pulindexStudent(student_stu** stuhead, int indexStu);
void printLinkedList(student_stu** stuhead, int indexStu);
void freeStudentList(student_stu* head);
student_stu* createStudentListFromFile(const char *filename);
void saveStudentList(student_stu* student_list_head);


